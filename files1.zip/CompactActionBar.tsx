'use client';

import { PastelColor, Label } from '@/types';

interface CompactActionBarProps {
  selectedColor: PastelColor | null;
  selectedLabel: Label | null;
  onColorSelect: (color: PastelColor) => void;
  onLabelSelect: (label: Label) => void;
}

const COLORS: PastelColor[] = ['pink', 'lavender', 'blue', 'mint', 'yellow', 'peach', 'rose', 'lilac'];
const LABELS: Label[] = ['✓', '★', '♥', '◆', '●', '▲', '■', '✕'];

const colorClasses: Record<PastelColor, string> = {
  pink: 'bg-pastel-pink',
  lavender: 'bg-pastel-lavender',
  blue: 'bg-pastel-blue',
  mint: 'bg-pastel-mint',
  yellow: 'bg-pastel-yellow',
  peach: 'bg-pastel-peach',
  rose: 'bg-pastel-rose',
  lilac: 'bg-pastel-lilac',
};

export default function CompactActionBar({
  selectedColor,
  selectedLabel,
  onColorSelect,
  onLabelSelect
}: CompactActionBarProps) {
  return (
    <div className="fixed right-4 top-1/2 transform -translate-y-1/2 flex flex-col gap-3 bg-white/90 backdrop-blur-sm p-2 rounded-xl shadow-soft border border-gray-100">
      {/* Fila de colores */}
      <div className="flex flex-col gap-1">
        <span className="text-[10px] font-display font-semibold text-gray-500 text-center mb-1">
          Colores
        </span>
        <div className="grid grid-cols-2 gap-1">
          {COLORS.map(color => (
            <button
              key={color}
              onClick={() => onColorSelect(color)}
              className={`
                ${colorClasses[color]}
                w-6 h-6 rounded-md transition-all
                ${selectedColor === color ? 'ring-2 ring-gray-800 scale-110' : 'hover:scale-105'}
              `}
              title={color}
            />
          ))}
        </div>
      </div>

      {/* Separador */}
      <div className="h-px bg-gray-200" />

      {/* Fila de iconos */}
      <div className="flex flex-col gap-1">
        <span className="text-[10px] font-display font-semibold text-gray-500 text-center mb-1">
          Íconos
        </span>
        <div className="grid grid-cols-2 gap-1">
          {LABELS.map(label => (
            <button
              key={label}
              onClick={() => onLabelSelect(label)}
              className={`
                w-6 h-6 rounded-md bg-gray-50 border transition-all
                flex items-center justify-center text-xs font-bold
                ${selectedLabel === label 
                  ? 'border-gray-800 bg-gray-100 scale-110' 
                  : 'border-gray-200 hover:border-gray-300 hover:scale-105'
                }
              `}
              title={label}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
