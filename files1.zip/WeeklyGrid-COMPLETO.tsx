'use client';

import { useState, useEffect, useRef } from 'react';
import { format, startOfWeek, addDays, subDays } from 'date-fns';
import { es } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import SlotButton from './SlotButton';
import CompactActionBar from './CompactActionBar';
import { getWeeklySlots, toggleSlot } from '@/lib/database';
import { useFingerprint } from '@/hooks/useFingerprint';
import { useOwner } from '@/hooks/useOwner';
import { Slot, PastelColor, Label } from '@/types';

const CORE_HOURS = [
  '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00',
  '15:00', '16:00', '17:00', '18:00'
];

const ALL_HOURS = Array.from({ length: 24 }, (_, i) => 
  `${i.toString().padStart(2, '0')}:00`
);

const EARLY_MORNING_1 = ['00:00', '01:00', '02:00', '03:00'];
const EARLY_MORNING_2 = ['04:00', '05:00', '06:00', '07:00'];
const EVENING_1 = ['19:00', '20:00', '21:00'];
const EVENING_2 = ['22:00', '23:00', '24:00'];

export default function WeeklyGrid() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [slots, setSlots] = useState<Slot[]>([]);
  const [selectedColor, setSelectedColor] = useState<PastelColor | null>(null);
  const [selectedLabel, setSelectedLabel] = useState<Label | null>(null);
  
  // Estado de expansión
  const [earlyExpansion, setEarlyExpansion] = useState<'collapsed' | 'semi' | 'full'>('collapsed');
  const [lateExpansion, setLateExpansion] = useState<'collapsed' | 'semi' | 'full'>('collapsed');

  // Estado de modo edición
  const [editMode, setEditMode] = useState(false);
  const [availability, setAvailability] = useState<Record<string, boolean>>({});

  // Estado para click sostenido
  const pressTimer = useRef<NodeJS.Timeout | null>(null);
  const [isPressing, setIsPressing] = useState(false);

  const { fingerprint } = useFingerprint();
  const { isOwner, isLoading: ownerLoading } = useOwner();

  const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  useEffect(() => {
    async function loadSlots() {
      const data = await getWeeklySlots(currentDate);
      console.log('📊 Slots cargados:', data.length);
      setSlots(data);
    }
    if (!editMode) {
      loadSlots();
    }
  }, [currentDate, editMode]);

  // Navegación de semanas
  const goToPreviousWeek = () => {
    setCurrentDate(prev => {
      const d = new Date(prev);
      d.setDate(d.getDate() - 7);
      return d;
    });
  };

  const goToNextWeek = () => {
    setCurrentDate(prev => {
      const d = new Date(prev);
      d.setDate(d.getDate() + 7);
      return d;
    });
  };

  const handleSlotClick = async (day: string, hour: string) => {
    if (!isOwner || editMode) return;
    if (!selectedColor || !selectedLabel) {
      console.log('⚠️ Primero selecciona un color y un ícono');
      return;
    }
    if (!fingerprint) return;

    const newSlot = await toggleSlot(day, hour, fingerprint, selectedColor, selectedLabel);
    if (newSlot) {
      console.log('✅ Guardado exitoso');
      setSlots(prev => {
        const filtered = prev.filter(s => !(s.day === day && s.hour === hour));
        return [...filtered, newSlot];
      });
    }
  };

  // Toggle disponibilidad en modo edición
  const handleAvailabilityToggle = (dayIndex: number, hour: string) => {
    const key = `${dayIndex}-${hour}`;
    setAvailability(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Guardar configuración
  const handleSaveConfiguration = () => {
    const name = prompt('Nombre de la configuración:');
    if (!name) return;

    const config = {
      name,
      availability
    };

    console.log('💾 Configuración guardada:', config);
    alert(`Configuración "${name}" guardada exitosamente!\n\nDisponibilidades marcadas: ${Object.values(availability).filter(Boolean).length}`);
  };

  // Click sostenido para colapsar/expandir
  const handleMouseDown = (action: () => void) => {
    setIsPressing(true);
    pressTimer.current = setTimeout(() => {
      action();
      setIsPressing(false);
    }, 500); // 500ms de espera
  };

  const handleMouseUp = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
    setIsPressing(false);
  };

  const handleGroupClick = (label: string) => {
    if (label === '00-07') {
      setEarlyExpansion('semi');
    } else if (label === '00-03' || label === '04-07') {
      setEarlyExpansion('full');
    } else if (label === '19-24') {
      setLateExpansion('semi');
    } else if (label === '19-21' || label === '22-24') {
      setLateExpansion('full');
    }
  };

  const toggleEarlyExpansion = () => {
    setEarlyExpansion(prev => {
      if (prev === 'collapsed') return 'semi';
      if (prev === 'semi') return 'full';
      return 'collapsed';
    });
  };

  const toggleLateExpansion = () => {
    setLateExpansion(prev => {
      if (prev === 'collapsed') return 'semi';
      if (prev === 'semi') return 'full';
      return 'collapsed';
    });
  };

  const getSlotData = (day: string, hour: string) => {
    return slots.find(s => s.day === day && s.hour === hour);
  };

  const renderHourRow = (hour: string, isGroup: boolean = false, groupLabel?: string) => {
    if (editMode) {
      // Modo edición: Celdas de disponibilidad
      return (
        <motion.div
          key={hour}
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.2 }}
          className="flex items-center mb-1"
        >
          <div className="w-14 flex-shrink-0 flex items-center justify-end mr-3">
            <span className="font-body text-gray-600 font-semibold text-xs">
              {hour}
            </span>
          </div>
          <div className="flex gap-1 flex-1">
            {weekDays.map((day, dayIndex) => {
              const key = `${dayIndex}-${hour}`;
              const isAvailable = availability[key];
              
              return (
                <div key={key} className="w-32 flex-shrink-0">
                  <button
                    onClick={() => handleAvailabilityToggle(dayIndex, hour)}
                    className={`
                      w-full h-8 rounded-lg transition-all duration-200
                      ${isAvailable ? 'bg-green-200 border-2 border-green-400' : 'bg-white border-2 border-gray-200'}
                      hover:scale-105 active:scale-95
                    `}
                  >
                    {isAvailable && (
                      <span className="text-green-700 text-xs font-bold">✓</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
          {/* Espacio simétrico derecho */}
          <div className="w-14 flex-shrink-0 ml-3" />
        </motion.div>
      );
    }

    // Modo normal
    return (
      <motion.div
        key={hour}
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.2 }}
        className="flex items-center mb-1"
      >
        <div className="w-14 flex-shrink-0 flex items-center justify-end mr-3">
          <span className="font-body text-gray-600 font-semibold text-xs">
            {hour}
          </span>
        </div>
        <div className="flex gap-1 flex-1">
          {weekDays.map((day, dayIndex) => {
            const dayStr = format(day, 'yyyy-MM-dd');
            const slotData = getSlotData(dayStr, hour);
            
            return (
              <div key={`${dayStr}-${hour}`} className="w-32 flex-shrink-0">
                {isGroup ? (
                  <button
                    onClick={() => handleGroupClick(groupLabel || hour)}
                    className="w-full h-8 rounded-lg bg-gray-50 border border-gray-200 hover:bg-gray-100 transition-colors flex items-center justify-center"
                  >
                    <span className="text-[10px] text-gray-400">•</span>
                  </button>
                ) : (
                  <SlotButton
                    day={dayStr}
                    hour={hour}
                    color={slotData?.color as PastelColor}
                    label={slotData?.label}
                    isOwner={isOwner}
                    onClick={() => handleSlotClick(dayStr, hour)}
                  />
                )}
              </div>
            );
          })}
        </div>
        {/* Espacio simétrico derecho */}
        <div className="w-14 flex-shrink-0 ml-3" />
      </motion.div>
    );
  };

  if (ownerLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="w-16 h-16 border-4 border-pastel-pink border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white p-2 md:p-3">
      <div className="max-w-full mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-3"
        >
          <h1 className="text-3xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-pastel-pink via-pastel-lavender to-pastel-blue mb-1">
            Mi Agenda Semanal
          </h1>
          <p className="text-gray-600 font-body text-xs">
            {editMode 
              ? '⚙️ Modo configuración: Marca tu disponibilidad semanal'
              : isOwner ? '✨ Selecciona color e ícono, luego toca las celdas' : '👀 Modo solo lectura'
            }
          </p>

          {/* Botones de control */}
          {isOwner && (
            <div className="flex gap-2 justify-center mt-3">
              <button
                onClick={() => setEditMode(!editMode)}
                className={`
                  px-4 py-2 rounded-lg font-display font-semibold text-sm
                  transition-all
                  ${editMode 
                    ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' 
                    : 'bg-blue-500 text-white hover:bg-600'
                  }
                `}
              >
                {editMode ? 'Finalizar edición' : 'Configurar disponibilidad'}
              </button>

              {editMode && (
                <button
                  onClick={handleSaveConfiguration}
                  className="px-4 py-2 rounded-lg font-display font-semibold text-sm bg-green-500 text-white hover:bg-green-600 transition-all"
                >
                  Guardar configuración
                </button>
              )}
            </div>
          )}
        </motion.div>

        <div className="flex items-start">
          <div className="w-full bg-gradient-to-br from-pastel-pink/10 via-pastel-lavender/10 to-pastel-blue/10 rounded-xl p-2 shadow-soft">
            <div className="overflow-x-auto">
              <div className="inline-block min-w-full">
                {/* Mes */}
                <div className="flex items-start mb-2">
                  <div className="w-14 flex-shrink-0 mr-3">
                    <div className="text-right">
                      <span className="font-display font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-pastel-pink to-pastel-lavender">
                        {format(weekStart, 'MMMM', { locale: es })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Días con flechas de navegación integradas */}
                <div className="flex items-center mb-2">
                  <div className="w-14 flex-shrink-0 flex items-center justify-end mr-3">
                    {/* Flecha izquierda - sin fondo */}
                    <button
                      onClick={goToPreviousWeek}
                      className="text-gray-600 hover:text-gray-900 transition-colors text-lg"
                      title="Semana anterior"
                    >
                      ←
                    </button>
                  </div>
                  <div className="flex gap-1 flex-1">
                    {weekDays.map(day => (
                      <div key={day.toString()} className="w-32 flex-shrink-0 text-center">
                        <div className="font-display font-bold text-gray-800 text-xs">
                          {format(day, 'EEEE d', { locale: es })}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="w-14 flex-shrink-0 flex items-center justify-start ml-3">
                    {/* Flecha derecha - sin fondo */}
                    <button
                      onClick={goToNextWeek}
                      className="text-gray-600 hover:text-gray-900 transition-colors text-lg"
                      title="Semana siguiente"
                    >
                      →
                    </button>
                  </div>
                </div>

                <div className="h-px bg-gray-200 mb-2" />

                {/* Horas */}
                {editMode ? (
                  // Modo edición: 24 horas
                  ALL_HOURS.map(hour => renderHourRow(hour))
                ) : (
                  // Modo normal: Con expansión
                  <>
                    <div
                      onMouseDown={() => handleMouseDown(toggleEarlyExpansion)}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                    >
                      <AnimatePresence mode="wait">
                        {earlyExpansion === 'collapsed' && (
                          <>{renderHourRow('00-07', true, '00-07')}</>
                        )}
                        {earlyExpansion === 'semi' && (
                          <>
                            {renderHourRow('00-03', true, '00-03')}
                            {renderHourRow('04-07', true, '04-07')}
                          </>
                        )}
                        {earlyExpansion === 'full' && (
                          <>
                            {EARLY_MORNING_1.map(h => renderHourRow(h))}
                            {EARLY_MORNING_2.map(h => renderHourRow(h))}
                          </>
                        )}
                      </AnimatePresence>
                    </div>

                    {CORE_HOURS.map(hour => renderHourRow(hour))}

                    <div
                      onMouseDown={() => handleMouseDown(toggleLateExpansion)}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                    >
                      <AnimatePresence mode="wait">
                        {lateExpansion === 'collapsed' && (
                          <>{renderHourRow('19-24', true, '19-24')}</>
                        )}
                        {lateExpansion === 'semi' && (
                          <>
                            {renderHourRow('19-21', true, '19-21')}
                            {renderHourRow('22-24', true, '22-24')}
                          </>
                        )}
                        {lateExpansion === 'full' && (
                          <>
                            {EVENING_1.map(h => renderHourRow(h))}
                            {EVENING_2.map(h => renderHourRow(h))}
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Barra de acciones compacta flotante - solo en modo normal */}
        {isOwner && !editMode && (
          <CompactActionBar
            selectedColor={selectedColor}
            selectedLabel={selectedLabel}
            onColorSelect={setSelectedColor}
            onLabelSelect={setSelectedLabel}
          />
        )}
      </div>
    </div>
  );
}
