# ═══════════════════════════════════════════════════════════════
# 🚀 SCRIPT DE ACTUALIZACIÓN - AGENDA SEMANAL
# ═══════════════════════════════════════════════════════════════
# Ejecutar desde la raíz del proyecto (C:\Carlos\Core\agenda-semanal)
# Comando: .\aplicar-cambios.ps1

Write-Host ""
Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   🚀 ACTUALIZACIÓN DE AGENDA SEMANAL" -ForegroundColor White
Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Verificar que estamos en la raíz del proyecto
if (-not (Test-Path ".\components")) {
    Write-Host "❌ ERROR: No se encuentra la carpeta 'components'" -ForegroundColor Red
    Write-Host "   Ejecuta este script desde la raíz del proyecto:" -ForegroundColor Yellow
    Write-Host "   C:\Carlos\Core\agenda-semanal\" -ForegroundColor Yellow
    Write-Host ""
    pause
    exit 1
}

# Crear carpeta de backups
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = ".\backups\backup_$timestamp"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null

Write-Host "📦 Paso 1: Creando respaldos..." -ForegroundColor Yellow
if (Test-Path ".\components\WeeklyGrid.tsx") {
    Copy-Item ".\components\WeeklyGrid.tsx" "$backupDir\WeeklyGrid.tsx.backup" -Force
    Write-Host "   ✓ WeeklyGrid.tsx respaldado" -ForegroundColor Green
}
Write-Host ""

# Verificar que los archivos descargados existen
Write-Host "📥 Paso 2: Verificando archivos descargados..." -ForegroundColor Yellow
Write-Host ""
Write-Host "   Necesitas tener estos archivos en la raíz del proyecto:" -ForegroundColor White
Write-Host "   • WeeklyGrid-COMPLETO.tsx" -ForegroundColor Cyan
Write-Host "   • CompactActionBar.tsx" -ForegroundColor Cyan
Write-Host ""

$weeklyGridSource = ".\WeeklyGrid-COMPLETO.tsx"
$compactActionBarSource = ".\CompactActionBar.tsx"

if (-not (Test-Path $weeklyGridSource)) {
    Write-Host "❌ ERROR: No se encuentra WeeklyGrid-COMPLETO.tsx" -ForegroundColor Red
    Write-Host "   Descárgalo desde Claude y colócalo en la raíz del proyecto" -ForegroundColor Yellow
    Write-Host ""
    pause
    exit 1
}

if (-not (Test-Path $compactActionBarSource)) {
    Write-Host "❌ ERROR: No se encuentra CompactActionBar.tsx" -ForegroundColor Red
    Write-Host "   Descárgalo desde Claude y colócalo en la raíz del proyecto" -ForegroundColor Yellow
    Write-Host ""
    pause
    exit 1
}

Write-Host "   ✓ WeeklyGrid-COMPLETO.tsx encontrado" -ForegroundColor Green
Write-Host "   ✓ CompactActionBar.tsx encontrado" -ForegroundColor Green
Write-Host ""

# Aplicar cambios
Write-Host "🔄 Paso 3: Aplicando cambios..." -ForegroundColor Yellow

# Reemplazar WeeklyGrid.tsx
Copy-Item $weeklyGridSource ".\components\WeeklyGrid.tsx" -Force
Write-Host "   ✓ WeeklyGrid.tsx actualizado" -ForegroundColor Green

# Crear CompactActionBar.tsx
Copy-Item $compactActionBarSource ".\components\CompactActionBar.tsx" -Force
Write-Host "   ✓ CompactActionBar.tsx creado" -ForegroundColor Green

Write-Host ""

# Limpiar archivos temporales
Write-Host "🧹 Paso 4: Limpiando archivos temporales..." -ForegroundColor Yellow
Remove-Item $weeklyGridSource -Force -ErrorAction SilentlyContinue
Remove-Item $compactActionBarSource -Force -ErrorAction SilentlyContinue
Write-Host "   ✓ Archivos temporales eliminados" -ForegroundColor Green
Write-Host ""

# Resumen
Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "   ✅ ACTUALIZACIÓN COMPLETADA EXITOSAMENTE" -ForegroundColor White
Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "📁 Archivos actualizados:" -ForegroundColor Yellow
Write-Host "   • components\WeeklyGrid.tsx (reemplazado)" -ForegroundColor White
Write-Host "   • components\CompactActionBar.tsx (nuevo)" -ForegroundColor White
Write-Host ""
Write-Host "📦 Respaldo guardado en:" -ForegroundColor Yellow
Write-Host "   $backupDir" -ForegroundColor Gray
Write-Host ""
Write-Host "🎯 Cambios aplicados:" -ForegroundColor Yellow
Write-Host "   ✓ Espacio simétrico w-14 a ambos lados" -ForegroundColor White
Write-Host "   ✓ Flechas de navegación ← → sin fondo" -ForegroundColor White
Write-Host "   ✓ Barra flotante derecha con colores e iconos" -ForegroundColor White
Write-Host "   ✓ Modo configuración de disponibilidad" -ForegroundColor White
Write-Host "   ✓ Click sostenido para expandir/colapsar horas" -ForegroundColor White
Write-Host ""
Write-Host "🚀 Próximos pasos:" -ForegroundColor Cyan
Write-Host "   1. El navegador se recargará automáticamente" -ForegroundColor White
Write-Host "   2. Verás la barra flotante a la derecha" -ForegroundColor White
Write-Host "   3. Las flechas ← → están en la línea de días" -ForegroundColor White
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
pause
